<?php
/**
 * Title: Hero (home)
 * Slug: triami/hero
 * Categories: triami
 * Description: Openingssectie met clubfoto op de achtergrond van de homepage met kop, intro, twee knoppen en de hartslaglijn.
 */
?>
<!-- wp:group {"className":"is-style-donker triami-hero","layout":{"type":"constrained","contentSize":"1200px"},"style":{"spacing":{"padding":{"top":"4rem","bottom":"0"}}}} -->
<div class="wp-block-group is-style-donker triami-hero" style="padding-top:4rem;padding-bottom:0">
<!-- wp:group {"layout":{"type":"constrained","contentSize":"760px","justifyContent":"left"}} -->
<div class="wp-block-group">
<!-- wp:paragraph {"fontSize":"klein","style":{"typography":{"textTransform":"uppercase","letterSpacing":"0.08em","fontWeight":"700"},"color":{"text":"#F36B6F"}}} -->
<p class="has-text-color has-klein-font-size" style="color:#F36B6F;font-weight:700;letter-spacing:0.08em;text-transform:uppercase">Triathlonvereniging Deventer en omstreken</p>
<!-- /wp:paragraph -->
<!-- wp:heading {"level":1} -->
<h1 class="wp-block-heading">Samen trainen, samen finishen</h1>
<!-- /wp:heading -->
<!-- wp:paragraph {"fontSize":"groot"} -->
<p class="has-groot-font-size">Zwemmen, fietsen en hardlopen onder begeleiding van gediplomeerde trainers, voor beginners én gevorderde triatleten. Kom kennismaken en train een keer gratis mee.</p>
<!-- /wp:paragraph -->
<!-- wp:buttons {"style":{"spacing":{"margin":{"top":"1.5rem"}}}} -->
<div class="wp-block-buttons" style="margin-top:1.5rem">
<!-- wp:button -->
<div class="wp-block-button"><a class="wp-block-button__link wp-element-button" href="/lidmaatschap/#meetrainen">Kom kennismaken</a></div>
<!-- /wp:button -->
<!-- wp:button {"className":"is-style-outline-wit"} -->
<div class="wp-block-button is-style-outline-wit"><a class="wp-block-button__link wp-element-button" href="/trainingen/">Bekijk de trainingen</a></div>
<!-- /wp:button -->
</div>
<!-- /wp:buttons -->
<!-- wp:paragraph {"className":"triami-hero-agenda","fontSize":"klein"} -->
<p class="triami-hero-agenda has-klein-font-size"><strong>Deventer Sprint Triathlon:</strong> jaarlijks begin mei. Meer informatie op de <a href="https://www.triathlondeventer.nl/" target="_blank" rel="noopener">wedstrijdsite</a>.</p>
<!-- /wp:paragraph -->
</div>
<!-- /wp:group -->
<!-- wp:spacer {"height":"2rem"} -->
<div style="height:2rem" aria-hidden="true" class="wp-block-spacer"></div>
<!-- /wp:spacer -->
<!-- wp:pattern {"slug":"triami/hartslaglijn"} /-->
</div>
<!-- /wp:group -->
